/*
 * CPS 202
 * Gabriela Calderon
 * date
 */
package PA7TicTacToe;

import java.lang.reflect.Array;

/**
 * File name:   TicTacToeModel.java
 * Description: The model must represent the board as a 2D array of String.
 * @author      Gabriela Calderon
 * @revision    April 7, 2021
 */

public class TicTacToeModel 
{    
    //------------CONSTANT FIELDS------------
    public static final int movesCount = 16;
    public static final int playerID = 1;
    public static final int size = 4;
    
    //------------INSTANCE FIELDS-------------
    public String[][] boardArray;
    private int[][] winHorizontal;
    private int[][] winVertical;
    private int[][] winDiagonal;
    private int[][] winConditions;


    //private Character winner = null;
    
    
    //-----------------CONSTRUCTORS----------------
    
    //No-arg constructor
    TicTacToeModel()
    {
        //boardArray = new ArrayList<>();
        
        //for (int i = 0; i < movesCount; i++)
        //    boardArray.add("");
        
        boardArray = new String [][] { {"", "", "", ""} , {"", "", "", ""},
                                    {"", "", "", ""}, {"", "", "", ""} };        
        /*
        winHorizontal = new int[][] { {0, 1, 2, 3}, {4, 5, 6, 7}, 
                                {8, 9, 10, 11}, {12, 13, 14, 15} };
        
        winVertical = new int[][] { {0, 4, 8, 12}, {1, 5, 9, 13}, 
                                {2, 6, 10, 14}, {3, 7, 11, 15} };

        winDiagonal = new int[][] { {0, 5, 10, 15}, {3, 6, 9, 12} };
        */
        
        winConditions = new int[][] { {0, 1, 2, 3}, {4, 5, 6, 7}, 
                                    {8, 9, 10, 11}, {12, 13, 14, 15},  
                                    {0, 4, 8, 12}, {1, 5, 9, 13}, 
                                    {2, 6, 10, 14}, {3, 7, 11, 15} ,
                                    {0, 5, 10, 15}, {3, 6, 9, 12} };
        /**
         * Conditions to win horizontally:  {0, 1, 2, 3}, {4, 5, 6, 7}, 
         *                                  {8, 9, 10, 11}, {12, 13, 14, 15}
         * Conditions to win vertically:    {0, 4, 8, 12}, {1, 5, 9, 13}, 
                                            {2, 6, 10, 14}, {3, 7, 11, 15}
         * Conditions to win diagonally:    {0, 5, 10, 15}, {3, 6, 9, 12}
         */
        
    }
    //--------------METHODS---------------        
    
    public String[] getCell(int index)
    {
        return boardArray[index];
    } //end public String getCell
        
    public void setCell(int row, int column, String value)
    {
        for (int r = 0; r < size; r++)
            for (int c = 0; c < size; c++){                
                if ((r == row) && (c == column))
                    boardArray[r][c] = value;
            }
    }        
      
    /**
     * Method that checks if a player won by testing out the different 
     * combinations of winning indexes.
     * @return boolean value.
     */
    public String getWin()
    {   
        /*String winner = null;       
        
        // Check for a horizontal winner
        winner = winHorizontal();
        
        if(winner != null){
            return winner;
        }
        
        // Check for a vertical winner
        winner = winVertical();
        
        if(winner != null){
            return winner;
        }
        
        // Check for a diagonal winner
        winner = winDiagonal();
        
        if(winner != null){
            return winner;
        }
        
        return null; */
        
        if (winHorizontal() != null)
        {
            return winHorizontal();
        }        
        else if (winVertical() != null)
        {
            return winVertical();
        }
        else if (winDiagonal() != null)
        {
            return winDiagonal();
        }
        return null;
            
        
    } //End of win method
    
    public boolean tie()
    {
        for (String[] cell : boardArray)
        {
            if (cell.equals(" "))
                return false;
        }
        return true;
    }
    
    public String winHorizontal(int rowIndex)
    {
        int counterO = 0;
        int counterX = 0;
    
        // Go through all columns and count which character is found
        for (int j = 0; j < size; j++)
        {
            if (boardArray[rowIndex][j].equals("O"))
            {
                counterO++;                
            }
            if(boardArray[rowIndex][j].equals("X"))
            {
                counterX++;                    
            }        
        }
        
        // Based on the values on each counter, return the corrresponding winner, if any
        if(counterO == size)
        {
            return "O";            
        }
        else if( counterX == size ){
            return "X";
        }
        else{
            return null;
        }        
    }
    
    public String winHorizontal()
    {
        String winnerCharacter = null;
        
        for (int r = 0; r < size; r++){
            
            // Evaluate a winner horizontally
            winnerCharacter = winHorizontal(r);
            
            if(winnerCharacter != null){
                return winnerCharacter;
            }
        }        
        return null;                
    }
    
    
    public String winVertical(int columnIndex)
    {
        int counterO = 0;
        int counterX = 0;
    
        // Go through all columns and count which character is found
        for (int j = 0; j < size; j++)
        {
            if (boardArray[j][columnIndex].equals("O"))
            {
                counterO++;                
            }
            if(boardArray[j][columnIndex].equals("X"))
            {
                counterX++;                    
            }        
        }
        
        // Based on the values on each counter, return the corrresponding winner, if any
        if(counterO == size)
        {
            return "O";            
        }
        else if( counterX == size ){
            return "X";
        }
        else{
            return null;
        }
    }
    /**
     * 
     */
    public String winVertical()
    {
        String winnerCharacter = null;
        
        for (int c = 0; c < size; c++){
            
            // Evaluate a winner horizontally
            winnerCharacter = winVertical(c);
            
            if(winnerCharacter != null){
                return winnerCharacter;
            }
        }        
        return null;          
    }
    
    public String winDiagonalLR(int j)
    {
        int counterOLR = 0;
        int counterXLR = 0;
        
        if (boardArray[j][j].equals("O"))
        {
            counterOLR++;                
        }
        else if(boardArray[j][j].equals("X"))
        {
            counterXLR++;                    
        }
        
        if(counterOLR == size)
        {
            return "O";            
        }
        else if (counterXLR == size )
        {
            return "X";
        }
        return null;
    }
    
    public String winDiagonalRL(int i)
    {        
        int counterORL = 0;
        int counterXRL = 0;                    
        
        // Get possible diagonals from right to left
        for (int j = 0; j < size; j++)
        {
            if (boardArray[i][(size-1) - j].equals("O"))
            {
                counterORL++;
            }
            else if (boardArray[i][(size-1) - j].equals("X"))
            {
                counterXRL++;
            }
        }        
        
        // Based on the values on each counter, return the corrresponding winner, if any
        if (counterORL == size)
        {
            return "O";
        }
        else if (counterXRL == size)
        {
            return "X";
        }
        else
        {
            return null;
        }
    }
    
    public String winDiagonal()
    {
        String winnerCharacterLR = null;
        String winnerCharacterRL = null;
        
        for (int j = 0; j < size; j++)
        {
            // Evaluate a winner diagonally, using rows and columns
            winnerCharacterRL = winDiagonalRL(j);
            winnerCharacterLR = winDiagonalLR(j);
            return winnerCharacterLR;
        }
        /*if (winnerCharacterRL != null)
        {
            return winnerCharacterRL;
        }
        else if (winnerCharacterLR != null)
        {
            return winnerCharacterLR;
        }*/
        return null;
    }
} //End of model class