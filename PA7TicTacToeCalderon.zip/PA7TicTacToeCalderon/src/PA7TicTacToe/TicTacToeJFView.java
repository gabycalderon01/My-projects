/*
 * CPS 202
 * Gabriela Calderon
 * date
 */
package PA7TicTacToe;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;

/**
 * File name:   TicTacToeJFView.java
 * Description: The view must represent the game layout as 2D array of
 *              JButton. *Cannot inherit from JFrame*
 * @author      Gabriela Calderon
 * @revision    April 7, 2021
 */

public class TicTacToeJFView 
{
    //----------------CONSTANT FIELDS-----------------
    public static final int height = 600;
    public static final int width = 600;
    public static final int boardsize = 4;
    
    //------------INSTANCE FIELDS-------------
    
    private JButton[][] gameButtonArray = new JButton[boardsize][boardsize];
    private JFrame frame;
    private JLabel messageLabel;
    private JPanel squareButtonPanel;
    private JButton squareButton;
    private JPanel resetButtonPanel;
    private JButton resetButton;
    
    //-----------------CONSTRUCTORS----------------
    
    //No-arg constructor
    TicTacToeJFView()
    {
        createAndShowGUI();
        //gameButtonArray = new JButton[][]
    }
    //--------------METHODS---------------
    /**
     * Creates and displays the GUI.
     */
    public void createAndShowGUI()
    {
        //First set up the JFrame
        frame = new JFrame("Tic-Tac-Toe");
        frame.setSize(width, height);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //or
        //frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        //Create the message area
        messageLabel = new JLabel("I want to play a game...");
        
        //Create the panel to store the game board buttons
        squareButtonPanel = new JPanel();
        squareButtonPanel.setLayout(new GridLayout(boardsize, boardsize));
        
        //Create buttons and add them to the squareButton panel
        for (int r = 0; r < boardsize; r++)
            for (int c = 0; c < boardsize; c++)
            {
                squareButton = new JButton(" ");
                squareButtonPanel.add(squareButton);
                gameButtonArray[r][c] = squareButton;
            }
        
        //Create the panel for the reset button
        resetButtonPanel = new JPanel();
        resetButtonPanel.setLayout(new BorderLayout());
        
        //Create reset button and add it to the resetButton panel
        resetButton = new JButton("Reset the board");
        resetButtonPanel.add(resetButton);
        
        //Add message area, and square and reset button panels to the frame
        frame.add(messageLabel, BorderLayout.NORTH); //Message on the top
        frame.add(squareButtonPanel, BorderLayout.CENTER); //Button in center        
        frame.add(resetButtonPanel, BorderLayout.SOUTH); //reset button in south
        
        //Display the frame
        frame.setVisible(true);
        
    } //End of createAndShowGUI() method
    
    /**
     * Adds a listener to the reset button
     * @param listener 
     */
    public void addListenerToResetButton(ActionListener listener)
    {
        resetButton.addActionListener(listener);
    } //End of addListenerToResetButton method
    
    /**
     * Adds a listener to square buttons
     * @param row
     * @param column
     * @param listener 
     */
    public void addListenersToSquareButtons(int row, int column, 
                        ActionListener listener)
    {
        gameButtonArray[row][column].addActionListener(listener);
    } //End of addListenersToSquareButtons method
    
    /**
     * Getter for the button array
     * @return  the game button array
     */
    public JButton[][] getGameButtonArray()
    {
        return gameButtonArray;
    }
    
    /**
     * Setter for the message label
     * @param tempLabel 
     */
    public void setMessageLabel(String tempLabel)
    {
        messageLabel.setText(tempLabel);
    }
    
    /**
     * Getter for the message label
     * @return 
     */
    public String getMessageLabel()
    {
        return messageLabel.getText();
    }
    
    /**
     * Setter for the square button
     * @param r
     * @param c
     * @param tempButton 
     */
    public void setSquareButton(int r, int c, JButton tempButton)
    {
        gameButtonArray[r][c] = tempButton;
    }
    
    /**
     * Getter for the square button
     * @param r
     * @param c
     * @return 
     */
    public JButton getSquareButton(int r, int c)
    {
        return gameButtonArray[r][c];
    }
    
    /**
     * Setter for the reset button
     * @param tempButton 
     */
    public void setResetButton(JButton tempButton)
    {
        resetButton = tempButton;
    }
    
    /**
     * Getter for the reset button
     * @return 
     */
    public JButton getResetButton()
    {
        return resetButton;
    }
    
    /**
     * When called hides the frame to start a new game
     */
    public void gameOver()
    {
        frame.setVisible(false);                       
    }
    
    /**
     * Displays whose turn it is
     * @param t 
     */
    public void displayTurn(String t)
    {
        messageLabel.setText("It's " + t + "'s turn.");
        //setMessageLabel("It's " + t + "'s turn.");
    }
    
    /**
     * Displays who won
     * @param w 
     */
    public void setWinner(String w)
    {
        messageLabel.setText("Congratulations! " + w + " is the winner!");
    }
    
    public void setTie()
    {
        messageLabel.setText("There is a tie!");
    }
    
    public void setPlayAgain()
    {
        resetButton.setText("Let's play again!");
    }
} //End of TicTacToeJFView class
    
    
