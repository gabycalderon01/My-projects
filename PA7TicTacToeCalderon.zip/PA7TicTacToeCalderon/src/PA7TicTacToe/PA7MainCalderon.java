/*
 * CPS 202
 * Gabriela Calderon
 * date
 */
package PA7TicTacToe;

/**
 * File name:   PA7MainCalderon.java
 * Description: this class handles files and arrays.
 * @author      Gabriela Calderon
 * @revision    April 7, 2021
 */
public class PA7MainCalderon 
{
    public static void main(String[] args)
    {
        TicTacToeModel model = new TicTacToeModel();
        TicTacToeJFController controller = new TicTacToeJFController();
        //TicTacToeJFView view = new TicTacToeJFView();
        //System.out.print(model.getBoardArray());
    }    
}
