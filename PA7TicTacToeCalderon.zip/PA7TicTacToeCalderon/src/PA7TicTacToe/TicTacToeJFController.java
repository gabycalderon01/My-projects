/*
 * CPS 202
 * Gabriela Calderon
 * date
 */
package PA7TicTacToe;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.Arrays;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.util.List;        
/**
 * File name:   TicTacToeJFController.java
 * Description: The controller must implement the MVC design.
 * @author      Gabriela Calderon
 * @revision    April 7, 2021
 */

public class TicTacToeJFController 
{
    //-------------------INSTANCE FIELDS-------------
    private TicTacToeModel model; //instance field of model class
    private TicTacToeJFView view; //instance field of view class
    private String turn;
    private JButton[][] gameArray;
    
    //--------------------CONSTRUCTORS---------------------
    /**
     * No-arg constructor.
     */
    public TicTacToeJFController()
    {                
        model = new TicTacToeModel();
        view = new TicTacToeJFView();
        turn = "O";
        gameArray = view.getGameButtonArray();
        runApplication();        
    } //End no-arg constructor
            
    //----------------------METHODS------------------------
    /**
     * Runs the game.
     */
    public void runApplication()
    {
        
        for (int r = 0; r < TicTacToeJFView.boardsize; r++)
            for (int c = 0; c < TicTacToeJFView.boardsize; c++)
            {
                view.addListenersToSquareButtons(r, c, new ButtonListener(r, c, 
                        gameArray[r][c]));
            }    
        view.addListenerToResetButton(new ButtonListener
                                                (view.getResetButton()));
                
    } //End of runApplication() method
    
    /**
     * Checks if the game is over
     * @return  whether or not the game is over
     */
    public boolean finishGame()
    {        
        if ((model.getWin()) == null)
        {                        
            //view.setWinner("X");
            //view.setPlayAgain();
            return false;
        }
        else if ((model.getWin()).equals("O"))
        {                        
            view.setWinner("O");
            view.setPlayAgain();
            return true;
        }
        else if (model.getWin().equals("X"))
        {
            view.setWinner("X");
            view.setPlayAgain();
            return true;
        }
        
        return false;
        
    } //End of finishGame method
        
    /**
     * Moves to the next turn
     */
    public void nextTurn()
    {        
        //do
        //{
        if (!finishGame())
            if (turn.equals("X"))
            {
                turn = "O";
                view.displayTurn(turn);
            }
        
            else if (turn.equals("O"))
            {
                turn = "X";
                view.displayTurn(turn);
            }
        //}
        //while (!finishGame());
        
    } //End of nextTurn method
    
    //--------------------INNER CLASS-----------------------
    private class ButtonListener implements ActionListener 
    {        
        //---------INNER INSTANCE FIELDS----------
        
        /**
         * Inner class constructor that handles the square button listeners
         * @param row
         * @param col   
         * @param buttonClicked 
         */
        public ButtonListener(int row, int col, JButton buttonClicked)
        {            
            view.addListenersToSquareButtons(row, col, this);
        }   
        
        /**
         * Inner class constructor that handles the reset button listener
         * @param buttonReset 
         */
        public ButtonListener(JButton buttonReset)
        {
            view.addListenerToResetButton(this);
        }
        
        //----------INNER INSTANCE METHODS-----------
        /**
         * Acts depending on the button pressed.
         * @param e     The ActionEvent related to the button pressed.
         */
        @Override
        public void actionPerformed(ActionEvent e) 
        {            
            JButton buttonClicked = (JButton)e.getSource();
            //String buttonText = ((JButton)e.getSource()).getText();
            String buttonText = buttonClicked.getActionCommand();
                                
            if (buttonText.equals(("Reset the board")) || 
                    (buttonText.equals("Let's play again!")))
            {
                view.gameOver();
                TicTacToeJFController controller = 
                                        new TicTacToeJFController();
            }            
            else if (buttonText.equals(" "))
            {
                if (turn.equals("X"))
                {
                    buttonClicked.setText(turn);
                    buttonClicked.setBackground(Color.cyan);
                    buttonClicked.setForeground(Color.black);
                    buttonClicked.setOpaque(true);                        
                    model.setCell(findButtonRow(buttonClicked), 
                        findButtonColumn(buttonClicked), turn);
                    //nextTurn();
                }    
                else if (turn.equals("O"))
                {
                    buttonClicked.setText(turn);
                    buttonClicked.setBackground(Color.green);
                    buttonClicked.setForeground(Color.black);
                    buttonClicked.setOpaque(true);                        
                    model.setCell(findButtonRow(buttonClicked), 
                        findButtonColumn(buttonClicked), turn);
                    //nextTurn();
                }                     
            System.out.println(Arrays.deepToString(model.boardArray));            
            nextTurn();
            }
        } //End of actionPerformed method
    
        public int findButtonRow(Object button)
        {
            int row = 0;
            for (int r = 0; r < gameArray.length; r++)
            {
                for (int c = 0; c < gameArray[0].length; c++)
                {
                    if (button.equals(gameArray[r][c])) 
                    {
                        //column = c;
                        row = r;
                    }
                }
            }
            return row;
        }
        
        public int findButtonColumn(Object button)
        {
            int column = 0;
            for (int r = 0; r < gameArray.length; r++) 
            {
                for (int c = 0; c < gameArray[0].length; c++) 
                {
                    if (button.equals(gameArray[r][c])) {                    
                        column = c;
                    }
                }
            }
            return column;
        }
                
            
    } //End of inner class ButtonListener
} //End of Controller class

